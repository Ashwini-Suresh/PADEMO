/**
 * @file FragmentEditProfilePresenter.java
 * @brief This java class represents the presenter class of the FragmentEditProfilePresenter,java
 * @author Karthika V T
 */
package com.example.personalaccounthmi.presenter;

import com.example.personalaccounthmi.MainActivityContract;

public class FragmentEditProfilePresenter implements MainActivityContract.EditProfilePresenter {
    @Override
    public void editUsername() {

    }
}
