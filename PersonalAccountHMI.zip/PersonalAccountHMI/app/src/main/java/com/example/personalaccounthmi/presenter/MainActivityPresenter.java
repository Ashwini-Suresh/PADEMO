/**
 * @file MainActivityPresenter.java
 * @brief This class act as a connection between the model class and view class
 * @author Karthika V T
 */
package com.example.personalaccounthmi.presenter;

public class MainActivityPresenter {

}

