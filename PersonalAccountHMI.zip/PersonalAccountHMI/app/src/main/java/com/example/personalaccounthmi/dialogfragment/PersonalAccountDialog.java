/**
 * @file PersonalAccountDialog.java
 * @brief this java class is used to be extended by all other dialog fragments in which common functionalities for the dialog fragments can be declared
 * @author Karthika V T
 */
package com.example.personalaccounthmi.dialogfragment;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import com.example.personalaccounthmi.R;

public class PersonalAccountDialog extends DialogFragment{



}

