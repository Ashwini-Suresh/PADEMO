/**
 * @file FragmentEditProfileModel.java
 * @brief this java class is the presenter class of FragmentAllProfile and communicates between the model and presenter
 * @author Karthika V T
 */
package com.example.personalaccounthmi.model;

public class FragmentEditProfileModel {
}
