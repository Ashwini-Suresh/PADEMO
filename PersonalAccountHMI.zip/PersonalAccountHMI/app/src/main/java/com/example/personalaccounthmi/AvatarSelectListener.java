package com.example.personalaccounthmi;

public interface AvatarSelectListener {
    void onAvatarClick(String avatar);
}
